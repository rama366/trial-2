import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpDown,
  ArrowUpRight,
  BarChart3,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  CircleDollarSign,
  Clock3,
  Command,
  CreditCard,
  Download,
  FileBarChart,
  FileSpreadsheet,
  FileText,
  Filter,
  Globe2,
  HelpCircle,
  Landmark,
  LayoutDashboard,
  ListFilter,
  LockKeyhole,
  Menu,
  MessageCircle,
  Moon,
  MoreHorizontal,
  Package,
  Percent,
  Phone,
  PiggyBank,
  Plus,
  Printer,
  Receipt,
  RotateCcw,
  Repeat2,
  RefreshCw,
  ScanLine,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  ShoppingBag,
  SlidersHorizontal,
  Sparkles,
  Sun,
  Tag,
  TrendingDown,
  TrendingUp,
  UploadCloud,
  UserRound,
  UsersRound,
  Wallet,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useTheme } from "@/contexts/ThemeContext";
import {
  budgets,
  categories,
  calculateVat,
  contacts,
  demoTransactions,
  expenseMix,
  formatTZS,
  healthScore,
  monthlyTrend,
  profitAndLoss,
  summarize,
  weeklyTrend,
  type Transaction,
} from "@/lib/ledger-data";
import {
  AdvancedAccountsPage,
  AdvancedBudgetsPage,
  AdvancedCalendarPage,
  AdvancedContactsPage,
  AdvancedDebtsPage,
  AdvancedInventoryPage,
  AdvancedInvoicesPage,
  AdvancedRecurringPage,
  AdvancedToolsPage,
  CommandPalette,
} from "@/pages/LedgerLineAdvanced";

type PageKey =
  | "dashboard"
  | "income"
  | "expenses"
  | "reports"
  | "budgets"
  | "debts"
  | "inventory"
  | "invoices"
  | "accounts"
  | "calendar"
  | "contacts"
  | "pos"
  | "notifications"
  | "settings"
  | "help"
  | "recurring"
  | "tools";

type NavItem = { label: string; path: PageKey; icon: LucideIcon };

const primaryNav: NavItem[] = [
  { label: "Overview", path: "dashboard", icon: LayoutDashboard },
  { label: "Income", path: "income", icon: ArrowUpRight },
  { label: "Expenses", path: "expenses", icon: ArrowDownRight },
  { label: "Reports", path: "reports", icon: BarChart3 },
];

const workspaceNav: NavItem[] = [
  { label: "Budgets & goals", path: "budgets", icon: PiggyBank },
  { label: "Customers & suppliers", path: "contacts", icon: UsersRound },
  { label: "Quick POS", path: "pos", icon: ShoppingBag },
  { label: "Inventory", path: "inventory", icon: Package },
  { label: "Invoices", path: "invoices", icon: FileText },
];

const toolNav: NavItem[] = [
  { label: "Debts", path: "debts", icon: CreditCard },
  { label: "Accounts", path: "accounts", icon: Wallet },
  { label: "Calendar", path: "calendar", icon: CalendarDays },
  { label: "Recurring", path: "recurring", icon: Repeat2 },
  { label: "Data & trust", path: "tools", icon: ShieldCheck },
];

const pageMeta: Record<PageKey, { eyebrow: string; title: string; description: string }> = {
  dashboard: { eyebrow: "Thursday, 01 October 2026", title: "Good morning, Amina.", description: "Here is the clearest view of how your business is moving." },
  income: { eyebrow: "Money in", title: "Income ledger", description: "Every sale, invoice and deposit in one quiet place." },
  expenses: { eyebrow: "Money out", title: "Expense ledger", description: "See what the business is spending before it becomes a surprise." },
  reports: { eyebrow: "Decisions, not data", title: "Reports & insights", description: "The numbers behind the month, ready to share." },
  budgets: { eyebrow: "Plan with confidence", title: "Budgets & goals", description: "Keep the important things funded and visible." },
  debts: { eyebrow: "Keep promises visible", title: "Debts & reminders", description: "Know what is owed to you, and what you owe." },
  inventory: { eyebrow: "Stock with intention", title: "Inventory", description: "Protect margin from the shelf to the sale." },
  invoices: { eyebrow: "Professional by default", title: "Invoices", description: "Send a better first impression, then mark it paid." },
  accounts: { eyebrow: "Every shilling accounted for", title: "Accounts & wallets", description: "Cash, bank and mobile money — reconciled simply." },
  calendar: { eyebrow: "Your month at a glance", title: "Calendar", description: "Transactions and due dates mapped to the days that matter." },
  contacts: { eyebrow: "People behind the numbers", title: "Customers & suppliers", description: "A clear history for every important relationship." },
  pos: { eyebrow: "Fast enough for the counter", title: "Quick POS", description: "Capture a sale in a few taps and keep the line moving." },
  notifications: { eyebrow: "Nothing important slips past", title: "Notifications", description: "Reminders and summaries, at the right time." },
  settings: { eyebrow: "Make it yours", title: "Business settings", description: "Currency, tax, language and the little things that make LedgerLine fit." },
  help: { eyebrow: "A good answer is close", title: "Help center", description: "Short guides for the moments when you need a hand." },
  recurring: { eyebrow: "Set it once", title: "Recurring transactions", description: "Automate rent, subscriptions and repeat income without duplicate entries." },
  tools: { eyebrow: "Make the ledger work harder", title: "Data, automation & trust", description: "Import statements, model what-if scenarios and keep a recoverable audit trail." },
};

function LogoMark({ light = false }: { light?: boolean }) {
  return (
    <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${light ? "bg-[#e8d7b6] text-[#132b35]" : "bg-[var(--navy)] text-[var(--gold)]"}`} aria-label="LedgerLine mark">
      <span className="serif text-lg font-bold tracking-tight">LL</span>
    </div>
  );
}

function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "green" | "gold" | "red" | "navy" }) {
  const tones = {
    neutral: "bg-secondary text-secondary-foreground",
    green: "bg-[#e4f0e8] text-[#2e7755] dark:bg-[#244439] dark:text-[#8fc5a5]",
    gold: "bg-[#f2e8d4] text-[#8a6735] dark:bg-[#473b28] dark:text-[#e6c88f]",
    red: "bg-[#f2e1df] text-[#a55e5a] dark:bg-[#4a302f] dark:text-[#e09a92]",
    navy: "bg-[#e4ebed] text-[#23424c] dark:bg-[#263d45] dark:text-[#d4e2e4]",
  };
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold ${tones[tone]}`}>{children}</span>;
}

function MetricCard({ label, value, change, positive = true, icon: Icon, accent = "green", onClick, comparison = "vs last month" }: { label: string; value: string; change: string; positive?: boolean; icon: LucideIcon; accent?: "green" | "gold" | "navy"; onClick?: () => void; comparison?: string }) {
  const accents = { green: "bg-[#e4f0e8] text-[#2e7755] dark:bg-[#244439] dark:text-[#8fc5a5]", gold: "bg-[#f2e8d4] text-[#8a6735] dark:bg-[#473b28] dark:text-[#e6c88f]", navy: "bg-[#e4ebed] text-[#23424c] dark:bg-[#263d45] dark:text-[#d4e2e4]" };
  return (
    <div onClick={onClick} role={onClick ? "button" : undefined} tabIndex={onClick ? 0 : undefined} className={`app-card lift flex min-h-[142px] flex-col justify-between p-5 ${onClick ? "cursor-pointer" : ""}`}>
      <div className="flex items-start justify-between">
        <span className="tiny-label">{label}</span>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${accents[accent]}`}><Icon size={16} strokeWidth={1.8} /></span>
      </div>
      <div>
        <div className="money serif mt-3 text-[25px] font-semibold tracking-tight text-foreground">{value}</div>
        <div className={`mt-2 flex items-center gap-1 text-xs font-semibold ${positive ? "text-[#2e7755] dark:text-[#8fc5a5]" : "text-[#a55e5a] dark:text-[#e09a92]"}`}>
          {positive ? <TrendingUp size={13} /> : <TrendingDown size={13} />} {change}
          <span className="font-normal text-muted-foreground">{comparison}</span>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: React.ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="tiny-label mb-1">{eyebrow}</div>}
        <h2 className="serif text-[21px] font-semibold tracking-tight text-foreground">{title}</h2>
      </div>
      {action}
    </div>
  );
}

function PeriodToggle({ period, setPeriod }: { period: string; setPeriod: (period: string) => void }) {
  return (
    <div className="flex items-center gap-1 rounded-xl border border-border bg-card p-1 text-xs font-semibold shadow-sm">
      {["This week", "This month", "This year", "Custom"].map(item => (
        <button key={item} onClick={() => setPeriod(item)} className={`focus-ring rounded-lg px-3 py-2 transition ${period === item ? "bg-[var(--navy)] text-white shadow-sm dark:bg-[var(--gold)] dark:text-[#132b35]" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>{item}</button>
      ))}
    </div>
  );
}

function ComparisonToggle({ comparison, setComparison }: { comparison: string; setComparison: (value: string) => void }) {
  return <label className="flex min-h-11 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-semibold text-muted-foreground">Compare <select value={comparison} onChange={event => setComparison(event.target.value)} className="bg-transparent font-bold text-foreground outline-none"><option>Last month</option><option>Same month last year</option></select></label>;
}
function TransactionRow({ transaction, compact = false, onClick }: { transaction: Transaction; compact?: boolean; onClick?: () => void }) {
  const isIncome = transaction.kind === "income";
  return (
    <div onClick={onClick} role={onClick ? "button" : undefined} className={`group flex items-center gap-3 border-b border-border/70 py-3.5 last:border-0 ${compact ? "" : "px-1"} ${onClick ? "cursor-pointer hover:bg-secondary/40" : ""}`}>
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[11px] font-bold text-white" style={{ backgroundColor: transaction.color }}>{transaction.initials}</div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-semibold text-foreground">{transaction.description}</div>
        <div className="mt-0.5 truncate text-xs text-muted-foreground">{transaction.counterparty} · {transaction.date}</div>
      </div>
      <div className="hidden text-right sm:block">
        <div className={`money text-sm font-semibold ${isIncome ? "text-[#2e7755] dark:text-[#8fc5a5]" : "text-foreground"}`}>{isIncome ? "+" : "−"}{formatTZS(transaction.amount)}</div>
        <div className="mt-0.5 text-[10px] text-muted-foreground">{transaction.account}</div>
      </div>
      <Pill tone={transaction.status === "Cleared" ? "green" : "gold"}>{transaction.status}</Pill>
      <button className="hidden h-8 w-8 items-center justify-center rounded-lg text-muted-foreground opacity-0 transition hover:bg-secondary group-hover:opacity-100 sm:flex" aria-label={`More actions for ${transaction.description}`}><MoreHorizontal size={16} /></button>
    </div>
  );
}

function MiniBar({ label, value, max, color, note }: { label: string; value: number; max: number; color: string; note?: string }) {
  const percent = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="mb-4 last:mb-0">
      <div className="mb-2 flex items-center justify-between gap-3 text-xs"><span className="font-semibold text-foreground">{label}</span><span className="money text-muted-foreground">{formatTZS(value, true)} <span className="text-[10px]">/ {formatTZS(max, true)}</span></span></div>
      <div className="h-2 rounded-full bg-secondary"><div className="h-2 rounded-full transition-all duration-500" style={{ width: `${percent}%`, backgroundColor: color }} /></div>
      <div className="mt-1.5 flex items-center justify-between text-[10px] text-muted-foreground"><span>{percent}% used</span>{note && <span className={percent >= 80 ? "font-semibold text-[#a55e5a]" : ""}>{note}</span>}</div>
    </div>
  );
}

function Dashboard({ transactions, setPage, period, setPeriod, comparison, setComparison, onQuickAdd, onOpenAssistant, online }: { transactions: Transaction[]; setPage: (page: PageKey) => void; period: string; setPeriod: (period: string) => void; comparison: string; setComparison: (value: string) => void; onQuickAdd: (kind?: "income" | "expense") => void; onOpenAssistant: () => void; online: boolean }) {
  const summary = summarize(transactions);
  const score = healthScore(summary);
  const cashBalance = 660000 + summary.profit;
  const yearOverYear = comparison === "Same month last year";
  const receivables = contacts.filter(contact => contact.type === "Customer").reduce((sum, contact) => sum + contact.balance, 0);
  const trend = period === "This week" ? weeklyTrend : monthlyTrend;
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 xl:flex-row xl:items-end">
        <div>
          <div className="tiny-label mb-2">Thursday, 01 October 2026 · Dar es Salaam</div>
          <h1 className="serif text-[32px] font-semibold tracking-[-0.04em] text-foreground sm:text-[38px]">Good morning, Amina.</h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">Here is the clearest view of what your business kept, spent, and still needs from the month.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2"><PeriodToggle period={period} setPeriod={setPeriod} /><ComparisonToggle comparison={comparison} setComparison={setComparison} /><span className={`flex min-h-11 items-center gap-2 rounded-xl px-3 text-xs font-semibold ${online ? "bg-[#e4f0e8] text-[#2e7755]" : "bg-[#f2e1df] text-[#a55e5a]"}`}>{online ? "Online · synced" : "Offline · pending sync"}</span><button onClick={() => onQuickAdd()} className="focus-ring flex min-h-11 items-center gap-2 rounded-xl bg-[var(--gold)] px-4 text-sm font-bold text-[#132b35] shadow-sm transition hover:brightness-105"><Plus size={17} /> Add transaction</button></div><div className="flex flex-wrap gap-2"><button onClick={() => onQuickAdd("income")} className="flex min-h-10 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold hover:bg-secondary"><ArrowUpRight size={14} className="text-[#2e7755]" /> Add sale</button><button onClick={() => onQuickAdd("expense")} className="flex min-h-10 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold hover:bg-secondary"><ArrowDownRight size={14} className="text-[#a55e5a]" /> Add expense</button><button onClick={() => { onQuickAdd("expense"); toast.info("Receipt scanner ready", { description: "Attach a receipt to review its extracted fields." }); }} className="flex min-h-10 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold hover:bg-secondary"><ScanLine size={14} /> Scan receipt</button><button onClick={() => setPage("tools")} className="flex min-h-10 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold hover:bg-secondary"><UploadCloud size={14} /> Import statement</button></div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        <MetricCard label="Total income" value={formatTZS(summary.income, true)} change={yearOverYear ? "+18.6%" : "+12.8%"} comparison={`vs ${comparison.toLowerCase()}`} icon={ArrowUpRight} accent="green" onClick={() => setPage("income")} />
        <MetricCard label="Total expenses" value={formatTZS(summary.expenses, true)} change={yearOverYear ? "+8.9%" : "+4.2%"} comparison={`vs ${comparison.toLowerCase()}`} icon={ArrowDownRight} positive={false} accent="gold" onClick={() => setPage("expenses")} />
        <MetricCard label="Net profit" value={formatTZS(summary.profit, true)} change={yearOverYear ? "+24.3%" : "+18.5%"} comparison={`vs ${comparison.toLowerCase()}`} icon={TrendingUp} accent="green" onClick={() => setPage("reports")} />
        <MetricCard label="Profit margin" value={`${summary.margin.toFixed(1)}%`} change={yearOverYear ? "+4.6 pts" : "+2.1 pts"} comparison={`vs ${comparison.toLowerCase()}`} icon={Percent} accent="gold" onClick={() => setPage("reports")} />
        <MetricCard label="Cash balance" value={formatTZS(cashBalance, true)} change={yearOverYear ? "+15.1%" : "+9.4%"} comparison={`vs ${comparison.toLowerCase()}`} icon={Wallet} accent="navy" onClick={() => setPage("accounts")} />
        <MetricCard label="Receivables" value={formatTZS(receivables, true)} change={yearOverYear ? "−12.4%" : "−6.8%"} comparison={`vs ${comparison.toLowerCase()}`} positive={false} icon={CircleDollarSign} accent="navy" onClick={() => setPage("contacts")} />
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.5fr_1fr]">
        <div onClick={() => setPage("reports")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6">
          <div className="flex items-start justify-between gap-4"><div><div className="tiny-label mb-1">Cash movement</div><h2 className="serif text-xl font-semibold">Income vs expenses</h2></div><button className="focus-ring rounded-lg p-2 text-muted-foreground hover:bg-secondary"><MoreHorizontal size={18} /></button></div>
          <div className="mt-5 h-[255px] w-full sm:h-[290px]">
            <ResponsiveContainer width="100%" height="100%"><BarChart data={trend} margin={{ top: 10, right: 4, bottom: 0, left: -18 }} barGap={7}>
              <CartesianGrid vertical={false} className="chart-grid" strokeDasharray="3 5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} tickFormatter={value => `${value}m`} /><Tooltip cursor={{ fill: "var(--secondary)", opacity: .55 }} contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 12 }} formatter={(value: number, name: string) => [`TZS ${value.toFixed(1)}m`, name === "income" ? "Income" : "Expenses"]} /><Bar dataKey="income" fill="var(--forest)" radius={[5, 5, 0, 0]} maxBarSize={18} /><Bar dataKey="expense" fill="var(--gold)" radius={[5, 5, 0, 0]} maxBarSize={18} />
            </BarChart></ResponsiveContainer>
          </div>
          <div className="mt-2 flex items-center gap-5 text-xs text-muted-foreground"><span className="flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full bg-[var(--forest)]" /> Income</span><span className="flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full bg-[var(--gold)]" /> Expenses</span><span className="ml-auto hidden sm:inline">TZS millions</span></div>
        </div>
        <div onClick={() => setPage("reports")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6">
          <div className="flex items-start justify-between gap-4"><div><div className="tiny-label mb-1">Your business at a glance</div><h2 className="serif text-xl font-semibold">Business Health</h2></div><button onClick={onOpenAssistant} className="focus-ring rounded-lg p-2 text-[var(--gold)] hover:bg-secondary" aria-label="Open finance assistant"><Sparkles size={18} /></button></div>
          <div className="mt-5 flex items-center gap-5"><div className="relative flex h-32 w-32 shrink-0 items-center justify-center rounded-full" style={{ background: `conic-gradient(var(--gold) ${score * 3.6}deg, var(--secondary) 0deg)` }}><div className="flex h-24 w-24 flex-col items-center justify-center rounded-full bg-card"><span className="serif text-3xl font-semibold">{score}</span><span className="tiny-label text-[9px]">out of 100</span></div></div><div><Pill tone="green"><CircleCheck size={12} /> Healthy</Pill><p className="mt-3 text-sm leading-6 text-muted-foreground">Your margins are holding. The next unlock is bringing transport spend back under plan.</p><button onClick={onOpenAssistant} className="mt-3 flex items-center gap-1 text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">See three ways to improve <ArrowRight size={13} /></button></div></div>
          <div className="ledger-rule mt-6 pt-4"><div className="grid grid-cols-3 gap-3"><div><div className="tiny-label text-[9px]">Runway</div><div className="money mt-1 text-sm font-semibold">4.8 mo</div></div><div><div className="tiny-label text-[9px]">OpEx / rev</div><div className="money mt-1 text-sm font-semibold">31.4%</div></div><div><div className="tiny-label text-[9px]">Payroll / rev</div><div className="money mt-1 text-sm font-semibold">18.2%</div></div></div></div>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
        <div className="app-card p-5 sm:p-6">
          <SectionTitle eyebrow="Latest movement" title="Recent transactions" action={<button onClick={() => setPage("income")} className="flex items-center gap-1 text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">View all <ChevronRight size={14} /></button>} />
          <div>{transactions.slice(0, 5).map(transaction => <TransactionRow key={transaction.id} transaction={transaction} onClick={() => setPage(transaction.kind === "income" ? "income" : "expenses")} />)}</div>
        </div>
        <div onClick={() => setPage("budgets")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6">
          <SectionTitle eyebrow="October plan" title="Budget vs actual" action={<button onClick={() => setPage("budgets")} className="text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">Manage</button>} />
          {budgets.slice(0, 3).map(item => <MiniBar key={item.name} label={item.name} value={item.spent} max={item.budget} color={item.color} note={item.spent / item.budget >= .8 ? "Near limit" : undefined} />)}
          <div className="mt-5 rounded-xl bg-[#f4efe6] p-4 dark:bg-[#243941]"><div className="flex items-center gap-2 text-xs font-bold"><CircleAlert size={14} className="text-[var(--gold)]" /> One budget needs attention</div><p className="mt-1.5 text-xs leading-5 text-muted-foreground">Transport is at 85% of its monthly plan with 12 days left.</p></div>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-3"><div onClick={() => setPage("budgets")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6"><SectionTitle eyebrow="Keep the good month moving" title="Profit goal" /><div className="flex items-end justify-between"><div className="money serif text-2xl font-semibold">{formatTZS(summary.profit, true)}</div><div className="text-xs text-muted-foreground">of TZS 5.0m</div></div><div className="mt-3 h-2 rounded-full bg-secondary"><div className="h-2 rounded-full bg-[var(--forest)]" style={{ width: `${Math.min(100, summary.profit / 5000000 * 100)}%` }} /></div><div className="mt-2 text-xs text-muted-foreground">{Math.round(summary.profit / 5000000 * 100)}% reached · 12 days left</div></div><div onClick={() => setPage("calendar")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6"><SectionTitle eyebrow="Cash commitments" title="Upcoming bills" /><div className="space-y-3"><div className="flex items-center justify-between text-sm"><span className="font-semibold">TANESCO · 12 Oct</span><span className="money">TZS 572k</span></div><div className="flex items-center justify-between text-xs text-muted-foreground"><span>Rent · 01 Oct</span><span className="money">TZS 650k</span></div></div></div><div onClick={() => setPage("invoices")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6"><SectionTitle eyebrow="Needs attention" title="Overdue invoices" /><div className="money serif text-2xl font-semibold text-[#a55e5a]">TZS 460k</div><p className="mt-2 text-xs leading-5 text-muted-foreground">One invoice is overdue. Send a reminder to Kijitonyama Office.</p><div className="mt-4 text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">Open invoice register <ArrowRight size={13} className="ml-1 inline" /></div></div></div>
      <div className="grid gap-5 lg:grid-cols-[1fr_1fr_.9fr]">
        <div onClick={() => setPage("reports")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6"><SectionTitle eyebrow="Profit over time" title="Profit trend" /><div className="h-[180px]"><ResponsiveContainer width="100%" height="100%"><LineChart data={trend} margin={{ top: 12, right: 4, bottom: 0, left: -25 }}><CartesianGrid vertical={false} className="chart-grid" strokeDasharray="3 5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} tickFormatter={value => `${value}m`} /><Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 12 }} formatter={(value: number) => [`TZS ${value.toFixed(1)}m`, "Profit"]} /><Line type="monotone" dataKey="profit" stroke="var(--gold)" strokeWidth={3} dot={{ r: 3, fill: "var(--gold)", strokeWidth: 0 }} activeDot={{ r: 5 }} /></LineChart></ResponsiveContainer></div></div>
        <div onClick={() => setPage("expenses")} role="button" tabIndex={0} className="app-card cursor-pointer p-5 sm:p-6"><SectionTitle eyebrow="Where spend is going" title="Expense breakdown" /><div className="flex items-center gap-4"><div className="h-[170px] w-[170px] shrink-0"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={expenseMix} dataKey="value" nameKey="name" innerRadius={52} outerRadius={78} paddingAngle={3} strokeWidth={0}>{expenseMix.map(item => <Cell key={item.name} fill={item.color} />)}</Pie><Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 12 }} formatter={(value: number) => [`${value}%`, "Share"]} /></PieChart></ResponsiveContainer></div><div className="min-w-0 flex-1 space-y-2.5">{expenseMix.map(item => <div key={item.name} className="flex items-center justify-between gap-3 text-xs"><span className="flex items-center gap-2 truncate"><i className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: item.color }} />{item.name}</span><span className="text-right font-semibold">{formatTZS(item.amount, true)}<span className="ml-1 text-[10px] text-muted-foreground">{item.value}%</span></span></div>)}</div></div></div>
        <div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="A useful nudge" title="Smart insight" /><div className="rounded-xl bg-[var(--navy)] p-4 text-[#f8f4eb] dark:bg-[#0f1d23]"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e8d7b6] text-[#132b35]"><Sparkles size={17} /></div><p className="mt-4 text-sm leading-6">Transport is <strong className="text-[#e8d7b6]">TZS 728k</strong>, or 14% of expenses. Saturday remains your best sales day.</p><button onClick={onOpenAssistant} className="mt-4 flex items-center gap-1 text-xs font-bold text-[#e8d7b6]">Ask Finance Guide <ArrowRight size={13} /></button></div><div className="mt-4 flex items-center justify-between text-xs"><span className="text-muted-foreground">Next bill due</span><span className="font-semibold">TANESCO · 12 Oct</span></div></div>
      </div>
    </div>
  );
}

function LedgerPage({ kind, transactions, onQuickAdd, search, setSearch }: { kind: "income" | "expense"; transactions: Transaction[]; onQuickAdd: () => void; search: string; setSearch: (value: string) => void }) {
  const isIncome = kind === "income";
  const list = transactions.filter(t => t.kind === kind && `${t.description} ${t.counterparty} ${t.category}`.toLowerCase().includes(search.toLowerCase()));
  const total = list.reduce((sum, t) => sum + t.amount, 0);
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="tiny-label mb-2">{isIncome ? "Sales, invoices, deposits" : "Operating costs, bills, stock"}</div><h1 className="serif text-[32px] font-semibold tracking-[-0.04em]">{isIncome ? "Income ledger" : "Expense ledger"}</h1><p className="mt-2 text-sm text-muted-foreground">{isIncome ? "Track the money your work is bringing in." : "See what the business is spending before it becomes a surprise."}</p></div><button onClick={onQuickAdd} className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[var(--gold)] px-4 text-sm font-bold text-[#132b35]"><Plus size={17} /> Add {isIncome ? "income" : "expense"}</button></div>
      <div className="grid gap-3 sm:grid-cols-3"><div className="app-card p-5"><div className="tiny-label">This month</div><div className="money serif mt-2 text-2xl font-semibold">{formatTZS(total, true)}</div><div className="mt-2 text-xs font-semibold text-[#2e7755]">+{isIncome ? "12.8" : "4.2"}% vs last month</div></div><div className="app-card p-5"><div className="tiny-label">Entries</div><div className="money serif mt-2 text-2xl font-semibold">{list.length}</div><div className="mt-2 text-xs text-muted-foreground">{isIncome ? "4 cleared · 1 pending" : "3 cleared · 1 pending"}</div></div><div className="app-card p-5"><div className="tiny-label">Average entry</div><div className="money serif mt-2 text-2xl font-semibold">{formatTZS(list.length ? total / list.length : 0, true)}</div><div className="mt-2 text-xs text-muted-foreground">Across selected period</div></div></div>
      <div className="app-card overflow-hidden"><div className="flex flex-col justify-between gap-3 border-b border-border p-4 sm:flex-row sm:items-center sm:p-5"><div className="relative w-full max-w-sm"><Search size={15} className="absolute left-3 top-3 text-muted-foreground" /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search entries, people or categories" className="focus-ring h-10 w-full rounded-lg border border-border bg-background pl-9 pr-3 text-xs outline-none placeholder:text-muted-foreground" /></div><div className="flex items-center gap-2"><button className="focus-ring flex h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold text-muted-foreground hover:bg-secondary"><Filter size={14} /> Filters</button><button onClick={() => toast.success("Import ready", { description: "Drop a CSV or Excel statement to start categorising transactions." })} className="focus-ring flex h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold text-muted-foreground hover:bg-secondary"><UploadCloud size={14} /> Import</button><button className="focus-ring hidden h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold text-muted-foreground hover:bg-secondary sm:flex"><Download size={14} /> Export</button></div></div><div className="hidden grid-cols-[1.3fr_1fr_.75fr_.85fr_110px] gap-3 border-b border-border bg-secondary/45 px-5 py-3 text-[10px] font-bold uppercase tracking-[.14em] text-muted-foreground md:grid"><span>Description</span><span>Category</span><span>Date</span><span className="text-right">Amount</span><span className="text-right">Status</span></div><div className="px-4 sm:px-5">{list.length ? list.map(transaction => <div key={transaction.id} className="group grid items-center gap-3 border-b border-border/70 py-4 last:border-0 md:grid-cols-[1.3fr_1fr_.75fr_.85fr_110px]"><div className="flex min-w-0 items-center gap-3"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[11px] font-bold text-white" style={{ backgroundColor: transaction.color }}>{transaction.initials}</div><div className="min-w-0"><div className="truncate text-sm font-semibold">{transaction.description}</div><div className="truncate text-xs text-muted-foreground">{transaction.counterparty} · {transaction.account}</div></div></div><div className="hidden text-xs text-muted-foreground md:block">{transaction.category}</div><div className="hidden text-xs text-muted-foreground md:block">{transaction.date}</div><div className={`money text-right text-sm font-semibold ${isIncome ? "text-[#2e7755] dark:text-[#8fc5a5]" : ""}`}>{isIncome ? "+" : "−"}{formatTZS(transaction.amount)}</div><div className="flex justify-end"><Pill tone={transaction.status === "Cleared" ? "green" : "gold"}>{transaction.status}</Pill></div></div>) : <div className="py-16 text-center text-sm text-muted-foreground">No matching {isIncome ? "income" : "expenses"} yet.</div>}</div></div>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-dashed border-border p-4 text-xs text-muted-foreground"><div className="flex items-center gap-2"><ScanLine size={15} className="text-[var(--gold)]" /><span>Receipt scanning will suggest amount, date, vendor and category from a photo.</span></div><button onClick={() => toast.info("Receipt scanner", { description: "Upload a receipt in the next step to review the extracted fields." })} className="font-bold text-[var(--forest)] dark:text-[var(--gold)]">Try scan <ArrowRight size={13} className="ml-1 inline" /></button></div>
    </div>
  );
}

function ReportsPage({ period, setPeriod, comparison, setComparison, transactions }: { period: string; setPeriod: (value: string) => void; comparison: string; setComparison: (value: string) => void; transactions: Transaction[] }) {
  const summary = summarize(transactions);
  const pnl = profitAndLoss(transactions);
  const vat = calculateVat(transactions);
  const exportReport = (format: "pdf" | "excel" | "csv") => {
    if (format === "pdf") { window.print(); toast.success("Print dialog opened", { description: "Choose Save as PDF to keep a PDF copy." }); return; }
    const rows = [["Date", "Type", "Description", "Category", "Amount (TZS)"], ...transactions.map(item => [item.date, item.kind, item.description, item.category, String(item.amount)])];
    const content = rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\n");
    const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const anchor = document.createElement("a"); anchor.href = url; anchor.download = `ledgerline-report-${period.toLowerCase().replaceAll(" ", "-")}.${format === "excel" ? "xls" : "csv"}`; anchor.click(); URL.revokeObjectURL(url);
    toast.success(`${format.toUpperCase()} export downloaded`);
  };
  return (
    <div className="space-y-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="tiny-label mb-2">Decisions, not data</div><h1 className="serif text-[32px] font-semibold tracking-[-0.04em]">Reports & insights</h1><p className="mt-2 text-sm text-muted-foreground">A clear read on your business, ready to share with an accountant.</p></div><div className="flex flex-wrap gap-2"><PeriodToggle period={period} setPeriod={setPeriod} /><ComparisonToggle comparison={comparison} setComparison={setComparison} /><div className="flex flex-wrap gap-2"><button onClick={() => exportReport("pdf")} className="flex min-h-11 items-center gap-2 rounded-xl bg-[var(--navy)] px-3 text-xs font-bold text-white dark:bg-[var(--gold)] dark:text-[#132b35]"><Printer size={14} /> PDF</button><button onClick={() => exportReport("excel")} className="flex min-h-11 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold"><FileSpreadsheet size={14} /> Excel</button><button onClick={() => exportReport("csv")} className="flex min-h-11 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-bold"><Download size={14} /> CSV</button></div></div></div><div className="grid gap-3 md:grid-cols-4"><div className="app-card p-5"><div className="tiny-label">Net profit</div><div className="money serif mt-2 text-2xl font-semibold">{formatTZS(summary.profit, true)}</div><div className="mt-2 text-xs text-[#2e7755]">Healthy margin</div></div><div className="app-card p-5"><div className="tiny-label">VAT collected</div><div className="money serif mt-2 text-2xl font-semibold">{formatTZS(vat.collected, true)}</div><div className="mt-2 text-xs text-muted-foreground">October 2026 · 18% taxable sales</div></div><div className="app-card p-5"><div className="tiny-label">VAT paid</div><div className="money serif mt-2 text-2xl font-semibold">{formatTZS(vat.paid, true)}</div><div className="mt-2 text-xs text-muted-foreground">October 2026 · 18% taxable purchases</div></div><div className="app-card border-[var(--gold)]/45 p-5"><div className="tiny-label">VAT owed</div><div className="money serif mt-2 text-2xl font-semibold text-[var(--gold)]">{formatTZS(vat.owed, true)}</div><div className="mt-2 text-xs font-semibold text-[var(--gold)]">Due 20 Oct</div></div></div><div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]"><div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="Core statement" title="Profit & loss" action={<button onClick={() => toast.info("Print view", { description: "Opening a printer-friendly report view." })} className="flex items-center gap-1 text-xs font-bold text-muted-foreground"><Printer size={14} /> Print</button>} /><div className="divide-y divide-border/70"><ReportLine label="Revenue" value={formatTZS(summary.income)} tone="green" /><ReportLine label="Cost of goods sold" value={formatTZS(pnl.costOfGoodsSold)} /><ReportLine label="Gross profit" value={formatTZS(pnl.grossProfit)} tone="green" strong /><ReportLine label="Operating expenses" value={formatTZS(pnl.operatingExpenses)} /><ReportLine label="Net profit" value={formatTZS(pnl.netProfit)} tone="green" strong /></div><div className="mt-5 flex flex-wrap gap-2"><button onClick={() => toast.success("CSV export ready")} className="flex min-h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold hover:bg-secondary"><FileSpreadsheet size={14} /> Excel</button><button onClick={() => toast.success("CSV export ready")} className="flex min-h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold hover:bg-secondary"><FileText size={14} /> CSV</button><button onClick={() => toast.success("PDF export ready")} className="flex min-h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold hover:bg-secondary"><FileBarChart size={14} /> PDF</button></div></div><div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="At a glance" title="Financial signals" /><div className="space-y-4"><SignalRow label="Revenue growth" value="+12.8%" note="Above your 10% target" positive /><SignalRow label="Operating expenses / revenue" value="31.4%" note="−2.2 pts vs last quarter" positive /><SignalRow label="Payroll / revenue" value="18.2%" note="Within healthy range" positive /><SignalRow label="Receivables days" value="11 days" note="3 days faster than August" positive /></div><div className="ledger-rule mt-6 pt-5"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e8d7b6] text-[#7c5b2f]"><Sparkles size={16} /></div><p className="text-xs leading-5 text-muted-foreground">Your best sales day is Saturday. Consider a small weekend bundle to lift margin without extra delivery cost.</p></div></div></div></div><div className="app-card overflow-hidden p-5 sm:p-6"><SectionTitle eyebrow="Shareable views" title="Available reports" /><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{["Cash Flow report", "Balance Sheet summary", "Income by Source", "Expense by Category", "Tax summary", "Year-over-Year comparison"].map((report, index) => <button onClick={() => toast.info(report, { description: "This report is ready to filter and export." })} key={report} className="lift flex items-center justify-between rounded-xl border border-border p-4 text-left"><div className="flex items-center gap-3"><div className={`flex h-9 w-9 items-center justify-center rounded-lg ${index % 2 ? "bg-[#e4ebed] text-[#23424c]" : "bg-[#f2e8d4] text-[#8a6735]"}`}><FileBarChart size={16} /></div><span className="text-sm font-semibold">{report}</span></div><ChevronRight size={16} className="text-muted-foreground" /></button>)}</div></div></div>
  );
}

function ReportLine({ label, value, tone, strong }: { label: string; value: string; tone?: "green"; strong?: boolean }) { return <div className={`flex items-center justify-between py-3.5 ${strong ? "font-semibold" : ""}`}><span className={strong ? "text-foreground" : "text-muted-foreground"}>{label}</span><span className={`money ${tone === "green" ? "text-[#2e7755] dark:text-[#8fc5a5]" : ""}`}>{value}</span></div>; }
function SignalRow({ label, value, note, positive }: { label: string; value: string; note: string; positive?: boolean }) { return <div className="flex items-start justify-between gap-3"><div><div className="text-sm font-semibold">{label}</div><div className="mt-1 text-xs text-muted-foreground">{note}</div></div><div className={`text-sm font-bold ${positive ? "text-[#2e7755] dark:text-[#8fc5a5]" : "text-[#a55e5a]"}`}>{value}</div></div>; }

function ContactsPage() {
  return <div className="space-y-6"><PageIntro meta={pageMeta.contacts} action={<button onClick={() => toast.success("Contact created", { description: "Add a customer or supplier to keep their balance and history close." })} className="flex min-h-11 items-center gap-2 rounded-xl bg-[var(--gold)] px-4 text-xs font-bold text-[#132b35]"><Plus size={16} /> Add contact</button>} /><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{contacts.map(contact => <div key={contact.name} className="app-card lift p-5"><div className="flex items-start justify-between"><div className="flex h-11 w-11 items-center justify-center rounded-2xl text-xs font-bold text-white" style={{ backgroundColor: contact.color }}>{contact.initials}</div><button className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary"><MoreHorizontal size={17} /></button></div><div className="mt-4 text-sm font-bold">{contact.name}</div><div className="mt-1 text-xs text-muted-foreground">{contact.type} · {contact.detail}</div><div className={`money serif mt-5 text-xl font-semibold ${contact.balance >= 0 ? "text-[#2e7755] dark:text-[#8fc5a5]" : "text-[#a55e5a]"}`}>{contact.balance >= 0 ? "Owes you " : "You owe "}{formatTZS(Math.abs(contact.balance), true)}</div><div className="mt-4 flex gap-2"><button onClick={() => toast.success(`WhatsApp ${contact.name}`)} className="flex min-h-10 flex-1 items-center justify-center gap-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-secondary"><MessageCircle size={14} /> WhatsApp</button><button onClick={() => toast.success(`Calling ${contact.name}`)} className="flex min-h-10 items-center justify-center gap-1.5 rounded-lg border border-border px-3 text-xs font-semibold hover:bg-secondary"><Phone size={14} /></button></div></div>)}</div><div className="app-card overflow-hidden p-5 sm:p-6"><SectionTitle eyebrow="Relationship history" title="Recent contact activity" action={<button className="text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">View directory</button>} />{demoTransactions.slice(0, 4).map(transaction => <TransactionRow key={transaction.id} transaction={transaction} />)}</div></div>;
}

function PosPage({ onAdd }: { onAdd: (amount: number, description: string) => void }) {
  const [cart, setCart] = useState<{ name: string; price: number; quantity: number }[]>([]);
  const products = [{ name: "Premium maize flour", price: 4200 }, { name: "Sunflower oil 1L", price: 7800 }, { name: "Laundry soap", price: 2600 }, { name: "Bottled water", price: 1000 }, { name: "Sugar 1kg", price: 3200 }, { name: "Tea leaves", price: 4500 }];
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const addProduct = (product: { name: string; price: number }) => setCart(current => { const found = current.find(item => item.name === product.name); return found ? current.map(item => item.name === product.name ? { ...item, quantity: item.quantity + 1 } : item) : [...current, { ...product, quantity: 1 }]; });
  return <div className="space-y-6"><PageIntro meta={pageMeta.pos} action={<Pill tone="green"><CircleCheck size={12} /> Till online</Pill>} /><div className="grid gap-5 xl:grid-cols-[1.35fr_.75fr]"><div className="app-card p-5 sm:p-6"><div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><div className="tiny-label">Choose a product</div><h2 className="serif text-xl font-semibold">Today's counter</h2></div><div className="flex items-center gap-2"><button className="flex h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold"><Search size={14} /> Search products</button><button onClick={() => toast.info("New product", { description: "Inventory item creation is ready from the product catalog." })} className="flex h-10 items-center gap-2 rounded-lg bg-secondary px-3 text-xs font-semibold"><Plus size={14} /> New</button></div></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{products.map(product => <button onClick={() => addProduct(product)} key={product.name} className="lift rounded-xl border border-border p-4 text-left"><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f2e8d4] text-[#8a6735] dark:bg-[#473b28] dark:text-[#e6c88f]"><ShoppingBag size={19} /></div><div className="mt-4 text-sm font-semibold">{product.name}</div><div className="money mt-1 text-sm text-muted-foreground">{formatTZS(product.price)}</div></button>)}</div></div><div className="app-card flex flex-col p-5 sm:p-6"><div className="flex items-start justify-between"><div><div className="tiny-label">Current sale</div><h2 className="serif text-xl font-semibold">Receipt preview</h2></div><span className="text-xs text-muted-foreground">#POS-2084</span></div><div className="mt-5 flex-1">{cart.length === 0 ? <div className="flex h-full min-h-[220px] flex-col items-center justify-center rounded-xl border border-dashed border-border text-center"><Receipt size={25} className="text-[var(--gold)]" /><p className="mt-3 text-sm font-semibold">Start with a product</p><p className="mt-1 max-w-[190px] text-xs leading-5 text-muted-foreground">Tap any item to build a shareable receipt in seconds.</p></div> : <div className="space-y-1">{cart.map(item => <div key={item.name} className="flex items-center justify-between gap-3 border-b border-border/70 py-3 text-sm"><div><div className="font-semibold">{item.name}</div><div className="text-xs text-muted-foreground">{item.quantity} × {formatTZS(item.price)}</div></div><div className="money font-semibold">{formatTZS(item.price * item.quantity)}</div></div>)}<div className="mt-4 flex items-center justify-between"><span className="text-sm text-muted-foreground">Subtotal</span><span className="money text-sm font-semibold">{formatTZS(total)}</span></div><div className="mt-2 flex items-center justify-between"><span className="text-sm text-muted-foreground">VAT (18%)</span><span className="money text-sm font-semibold">{formatTZS(total * .18)}</span></div><div className="ledger-rule mt-4 flex items-center justify-between pt-4"><span className="font-semibold">Total</span><span className="money serif text-xl font-semibold">{formatTZS(total * 1.18)}</span></div></div>}</div><div className="mt-5 grid grid-cols-2 gap-2"><button onClick={() => toast.info("Receipt sharing", { description: "Choose WhatsApp, SMS or print for this receipt." })} className="flex min-h-11 items-center justify-center gap-2 rounded-xl border border-border text-xs font-semibold"><Send size={14} /> Share receipt</button><button disabled={!cart.length} onClick={() => { onAdd(total * 1.18, "POS counter sale"); setCart([]); }} className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[var(--forest)] text-xs font-bold text-white disabled:cursor-not-allowed disabled:opacity-40 dark:bg-[var(--gold)] dark:text-[#132b35]"><Check size={14} /> Complete sale</button></div></div></div></div>;
}

function PageIntro({ meta, action }: { meta: { eyebrow: string; title: string; description: string }; action?: React.ReactNode }) { return <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="tiny-label mb-2">{meta.eyebrow}</div><h1 className="serif text-[32px] font-semibold tracking-[-0.04em]">{meta.title}</h1><p className="mt-2 text-sm text-muted-foreground">{meta.description}</p></div>{action}</div>; }

function SettingsPanel() {
  const [language, setLanguage] = useState("English");
  const [currency, setCurrency] = useState("TZS — Tanzanian Shilling");
  const [twoFactor, setTwoFactor] = useState(false);
  const [weekly, setWeekly] = useState(true);
  return <div className="space-y-6"><PageIntro meta={pageMeta.settings} /><div className="grid gap-5 lg:grid-cols-2"><div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="Business profile" title="Make LedgerLine yours" /><div className="mt-5 grid gap-3 sm:grid-cols-2"><label className="text-xs font-semibold">Business name<input defaultValue="Amina's General Store" className="mt-2 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm" /></label><label className="text-xs font-semibold">Currency<select value={currency} onChange={event => setCurrency(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm"><option>TZS — Tanzanian Shilling</option><option>KES — Kenyan Shilling</option><option>USD — US Dollar</option></select></label><label className="text-xs font-semibold">Language<select value={language} onChange={event => setLanguage(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm"><option>English</option><option>Swahili</option></select></label><label className="text-xs font-semibold">VAT rate<input defaultValue="18" type="number" className="mt-2 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm" /></label></div><button onClick={() => toast.success("Settings saved", { description: `${language} · ${currency}` })} className="mt-5 min-h-11 rounded-xl bg-[var(--gold)] px-4 text-xs font-bold text-[#132b35]">Save business settings</button></div><div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="Team & access" title="Users and roles" /><div className="mt-4 space-y-2"><div className="flex items-center justify-between rounded-xl border border-border p-3"><span className="text-sm font-semibold">Amina G. <span className="ml-2 text-xs text-muted-foreground">Owner</span></span><span className="text-xs text-[#2e7755]">Full access</span></div><div className="flex items-center justify-between rounded-xl border border-border p-3"><span className="text-sm font-semibold">Accountant seat</span><select className="rounded-lg border border-border bg-background px-2 py-1 text-xs"><option>Accountant</option><option>Staff</option></select></div></div><button onClick={() => toast.success("Invite link copied")} className="mt-4 flex min-h-10 items-center gap-2 rounded-xl border border-border px-3 text-xs font-bold"><UsersRound size={14} /> Invite team member</button></div><div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="Notifications" title="Choose what reaches you" /><div className="mt-4 space-y-3"><label className="flex items-center justify-between text-sm"><span>Weekly profit summary</span><input type="checkbox" checked={weekly} onChange={event => setWeekly(event.target.checked)} /></label><label className="flex items-center justify-between text-sm"><span>Overdue invoice reminders</span><input type="checkbox" defaultChecked /></label><label className="flex items-center justify-between text-sm"><span>Low-stock alerts</span><input type="checkbox" defaultChecked /></label></div></div><div className="app-card p-5 sm:p-6"><SectionTitle eyebrow="Security & data" title="Protect and recover your ledger" /><div className="mt-4 space-y-3"><label className="flex items-center justify-between text-sm"><span>PIN / 2FA protection</span><input type="checkbox" checked={twoFactor} onChange={event => setTwoFactor(event.target.checked)} /></label><div className="flex flex-wrap gap-2"><button onClick={() => toast.success("Backup export ready")} className="flex min-h-10 items-center gap-2 rounded-xl border border-border px-3 text-xs font-bold"><Download size={14} /> Export backup</button><button onClick={() => toast.info("Restore", { description: "Choose a LedgerLine backup from Data & trust." })} className="flex min-h-10 items-center gap-2 rounded-xl border border-border px-3 text-xs font-bold"><RefreshCw size={14} /> Restore</button><button onClick={() => toast.success("Categories saved")} className="flex min-h-10 items-center gap-2 rounded-xl border border-border px-3 text-xs font-bold"><Tag size={14} /> Manage categories</button></div></div></div></div></div>;
}

function HelpCenter() {
  const [query, setQuery] = useState("");
  const guides = [
    ["Import a mobile-money statement", "Upload M-Pesa, Airtel Money, Mixx by Yas or bank CSV and review suggested categories."],
    ["Understand your profit", "Revenue minus cost of goods sold gives gross profit; operating expenses then give net profit."],
    ["Create and send an invoice", "Add line items, VAT, a due date and notes, then preview, print, WhatsApp or email."],
    ["Run a POS sale", "Choose products, adjust quantity, apply discount, select payment method and complete the sale."],
    ["Set a recurring rule", "Choose income or expense, category, account, cadence, start date and optional end date."],
    ["Manage stock and reorder points", "Edit products, restock quantity, review movement history and act on low-stock alerts."],
    ["Close and lock a month", "Review reports and VAT first, then lock the month so finished entries cannot change."],
    ["Work offline and sync", "Entries are queued locally while offline and sync automatically when the connection returns."],
    ["Invite a team member", "Use Settings to assign Owner, Accountant or Staff access and control profit visibility."],
  ];
  const visible = guides.filter(([title, text]) => `${title} ${text}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="space-y-6"><PageIntro meta={pageMeta.help} /><div className="app-card p-5 sm:p-6"><div className="flex items-center gap-3 rounded-xl border border-border bg-background px-3"><Search size={16} className="text-muted-foreground" /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search help guides..." className="h-11 min-w-0 flex-1 bg-transparent text-sm outline-none" /></div><div className="mt-5 grid gap-3 md:grid-cols-2">{visible.map(([title, text]) => <details key={title} className="group rounded-xl border border-border p-4"><summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-bold">{title}<ChevronDown size={15} className="transition group-open:rotate-180" /></summary><p className="mt-3 text-xs leading-5 text-muted-foreground">{text}</p></details>)}</div>{!visible.length && <div className="py-10 text-center text-sm text-muted-foreground">No guide matches “{query}”.</div>}</div></div>;
}

function UtilityPage({ page }: { page: PageKey }) {
  const meta = pageMeta[page];
  const cards: Record<string, { title: string; text: string; icon: LucideIcon; cta: string }[]> = {
    budgets: [{ title: "Monthly category budgets", text: "Give every important cost a ceiling and get a calm nudge before it goes over.", icon: PiggyBank, cta: "Add budget" }, { title: "Profit goal", text: "TZS 4.2m of TZS 5.0m monthly goal reached.", icon: TrendingUp, cta: "Adjust goal" }],
    debts: [{ title: "Money owed to you", text: "3 open customer balances · TZS 1.92m outstanding.", icon: ArrowUpRight, cta: "Add receivable" }, { title: "Money you owe", text: "2 supplier balances · next due in 6 days.", icon: ArrowDownRight, cta: "Add payable" }],
    inventory: [{ title: "Stock health", text: "28 products in catalog · 4 items below reorder point.", icon: Package, cta: "Review stock" }, { title: "Gross margin", text: "Average product margin is 32.6% this month.", icon: Tag, cta: "View products" }],
    invoices: [{ title: "Awaiting payment", text: "TZS 1.92m across 4 open invoices.", icon: Clock3, cta: "Create invoice" }, { title: "Paid this month", text: "12 invoices cleared automatically into income.", icon: CircleCheck, cta: "View paid" }],
    accounts: [{ title: "Cash & mobile money", text: "Cash on hand, M-Pesa Till and Airtel Money in one view.", icon: Wallet, cta: "Add account" }, { title: "Bank accounts", text: "NMB Business · last reconciled today.", icon: Landmark, cta: "Reconcile" }],
    calendar: [{ title: "October commitments", text: "7 due dates and 28 transactions mapped to your month.", icon: CalendarDays, cta: "View calendar" }, { title: "Next reminder", text: "TANESCO bill due in 12 days · TZS 78,000.", icon: Bell, cta: "Set reminder" }],
    notifications: [{ title: "Weekly profit summary", text: "Delivered every Monday at 08:00 by email, WhatsApp or SMS.", icon: Send, cta: "Choose channel" }, { title: "Low-stock alerts", text: "4 products need attention before the weekend rush.", icon: CircleAlert, cta: "Review alerts" }],
    help: [{ title: "Import a statement", text: "Upload M-Pesa, Tigo Pesa, Airtel Money or bank statements and review suggested categories.", icon: UploadCloud, cta: "Read guide" }, { title: "Close your month", text: "Lock a finished month so numbers cannot be changed by accident.", icon: LockKeyhole, cta: "Read guide" }],
    settings: [{ title: "Business profile", text: "Amina's General Store · Dar es Salaam · Financial year starts January.", icon: BriefcaseBusiness, cta: "Edit profile" }, { title: "VAT & tax mode", text: "VAT enabled at 18% · collected and paid tracked separately.", icon: Percent, cta: "Manage tax" }],
  };
  const items = cards[page] ?? cards.settings;
  if (page === "settings") return <SettingsPanel />;
  if (page === "help") return <HelpCenter />;
  return <div className="space-y-6"><PageIntro meta={meta} action={<button onClick={() => toast.success("Saved", { description: `${meta.title} is ready for your next step.` })} className="flex min-h-11 items-center gap-2 rounded-xl bg-[var(--gold)] px-4 text-xs font-bold text-[#132b35]"><Plus size={16} /> New</button>} /><div className="grid gap-4 lg:grid-cols-2">{items.map(item => <div key={item.title} className="app-card lift p-6"><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#f2e8d4] text-[#8a6735] dark:bg-[#473b28] dark:text-[#e6c88f]"><item.icon size={19} /></div><h2 className="serif mt-5 text-xl font-semibold">{item.title}</h2><p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">{item.text}</p><button onClick={() => toast.info(item.title, { description: "This workflow is ready to configure in your LedgerLine workspace." })} className="mt-5 flex items-center gap-1 text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">{item.cta} <ArrowRight size={13} /></button></div>)}</div><div className="app-card p-6"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="tiny-label">LedgerLine keeps improving</div><h2 className="serif mt-1 text-xl font-semibold">Need a hand with {meta.title.toLowerCase()}?</h2><p className="mt-1 text-sm text-muted-foreground">Ask Finance Guide in plain language, or open the help center for a short walkthrough.</p></div><button onClick={() => toast.info("Finance Guide", { description: "Try asking: How much did I spend on transport last month?" })} className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[var(--navy)] px-4 text-xs font-bold text-white dark:bg-[var(--gold)] dark:text-[#132b35]"><Sparkles size={15} /> Ask Finance Guide</button></div></div></div>;
}

function AssistantPanel({ onClose, transactions }: { onClose: () => void; transactions: Transaction[] }) {
  type Message = { role: "assistant" | "user"; text: string; chart?: Array<{ label: string; value: number }>; actions?: string[] };
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([{ role: "assistant", text: "I read the current ledger, not a generic example. Ask about profit, transport, savings, cash, or what changed." }]);
  const ask = trpc.assistant.ask.useMutation();
  const chips = ["Why did profit change?", "How can I cut transport costs?", "How do I raise income?", "What should I save this month?"];
  const send = (question = input) => { const prompt = question.trim(); if (!prompt || ask.isPending) return; setMessages(current => [...current, { role: "user", text: prompt }]); setInput(""); ask.mutate({ question: prompt, transactions: transactions.map(({ kind, amount, category, description, date, account, counterparty }) => ({ kind, amount, category, description, date, account, counterparty })) }, { onSuccess: result => setMessages(current => [...current, { role: "assistant", text: result.answer, chart: result.chart, actions: result.actions }]), onError: () => setMessages(current => [...current, { role: "assistant", text: "I couldn't reach the secure Finance Guide service. Your ledger is still safe; try again in a moment." }]) }); };
  return <div className="fixed inset-x-3 bottom-3 z-50 flex max-h-[82vh] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl sm:inset-auto sm:bottom-6 sm:right-6 sm:w-[430px]"><div className="flex items-center justify-between bg-[var(--navy)] p-4 text-white dark:bg-[#0f1d23]"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e8d7b6] text-[#132b35]"><Sparkles size={17} /></div><div><div className="text-sm font-bold">Finance Guide</div><div className="mt-0.5 text-[10px] text-[#cddbd6]">Secure AI analysis of your ledger</div></div></div><button onClick={onClose} className="rounded-lg p-1.5 text-white/70 hover:bg-white/10" aria-label="Close finance guide"><X size={17} /></button></div><div className="app-scroll min-h-[250px] flex-1 overflow-y-auto p-4">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`mb-4 flex ${message.role === "user" ? "justify-end" : "justify-start"}`}><div className={`max-w-[90%] rounded-2xl px-3.5 py-3 text-xs leading-5 ${message.role === "user" ? "rounded-br-sm bg-[var(--forest)] text-white dark:bg-[#2c5c4e]" : "rounded-bl-sm bg-secondary text-foreground"}`}><div>{message.text}</div>{message.chart?.length ? <div className="mt-3 space-y-1.5">{message.chart.slice(0, 5).map(point => <div key={point.label} className="flex items-center gap-2"><span className="w-16 truncate text-[10px] text-muted-foreground">{point.label}</span><div className="h-2 flex-1 rounded-full bg-background"><div className="h-2 rounded-full bg-[var(--gold)]" style={{ width: `${Math.min(100, Math.max(4, point.value))}%` }} /></div><span className="w-8 text-right text-[10px] font-bold">{point.value}</span></div>)}</div> : null}{message.actions?.length ? <div className="mt-3 border-t border-border/70 pt-2 text-[10px] text-muted-foreground">Next: {message.actions.join(" · ")}</div> : null}</div></div>)}{ask.isPending && <div className="text-xs text-muted-foreground">Finance Guide is reading the ledger…</div>}</div><div className="border-t border-border p-3"><div className="mb-3 flex flex-wrap gap-1.5">{chips.map(chip => <button key={chip} onClick={() => send(chip)} className="rounded-full border border-border px-2.5 py-1.5 text-[10px] font-semibold hover:bg-secondary">{chip}</button>)}</div><div className="flex items-center gap-2 rounded-xl border border-border bg-background p-1.5"><input value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => event.key === "Enter" && send()} placeholder="Ask about your finances..." className="h-9 min-w-0 flex-1 bg-transparent px-2 text-xs outline-none placeholder:text-muted-foreground" /><button onClick={() => send()} className="flex h-9 w-9 items-center justify-center rounded-lg bg-[var(--gold)] text-[#132b35]" aria-label="Send question"><Send size={15} /></button></div></div></div>;
}

function QuickAddModal({ initialKind = "income", onClose, onSave }: { initialKind?: "income" | "expense"; onClose: () => void; onSave: (draft: { kind: "income" | "expense"; amount: number; description: string; category: string; counterparty: string; account: string }) => void }) {
  const [kind, setKind] = useState<"income" | "expense">(initialKind);
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState(kind === "income" ? "Retail sales" : "Transport");
  const [counterparty, setCounterparty] = useState("");
  const [receiptName, setReceiptName] = useState("");
  const submit = (event: React.FormEvent) => { event.preventDefault(); if (!amount || !description) { toast.error("Add an amount and short description"); return; } onSave({ kind, amount: Number(amount.replace(/,/g, "")), description, category, counterparty: counterparty || (kind === "income" ? "Walk-in customer" : "General expense"), account: "M-Pesa Till" }); };
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#132b35]/40 p-3 backdrop-blur-sm sm:items-center"><form onSubmit={submit} className="app-card w-full max-w-lg p-5 shadow-2xl sm:p-6"><div className="flex items-start justify-between"><div><div className="tiny-label">Under five seconds</div><h2 className="serif mt-1 text-2xl font-semibold">Add a transaction</h2><p className="mt-1 text-sm text-muted-foreground">It will flow through profit, reports and your balance.</p></div><button type="button" onClick={onClose} className="rounded-lg p-2 text-muted-foreground hover:bg-secondary"><X size={18} /></button></div><div className="mt-5 grid grid-cols-2 gap-2 rounded-xl bg-secondary p-1"><button type="button" onClick={() => { setKind("income"); setCategory("Retail sales"); }} className={`min-h-11 rounded-lg text-xs font-bold ${kind === "income" ? "bg-card text-[#2e7755] shadow-sm" : "text-muted-foreground"}`}>Money in</button><button type="button" onClick={() => { setKind("expense"); setCategory("Transport"); }} className={`min-h-11 rounded-lg text-xs font-bold ${kind === "expense" ? "bg-card text-[#a55e5a] shadow-sm" : "text-muted-foreground"}`}>Money out</button></div><div className="mt-5 grid gap-4 sm:grid-cols-2"><label className="sm:col-span-2"><span className="tiny-label mb-1.5 block">Amount · TZS</span><input autoFocus value={amount} onChange={event => setAmount(event.target.value)} inputMode="decimal" placeholder="0" className="money focus-ring h-12 w-full rounded-xl border border-border bg-background px-3 text-lg font-semibold outline-none placeholder:text-muted-foreground" /></label><label><span className="tiny-label mb-1.5 block">What was it?</span><input value={description} onChange={event => setDescription(event.target.value)} placeholder={kind === "income" ? "Counter sale" : "Fuel for delivery"} className="focus-ring h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none placeholder:text-muted-foreground" /></label><label><span className="tiny-label mb-1.5 block">Customer / vendor</span><input value={counterparty} onChange={event => setCounterparty(event.target.value)} placeholder={kind === "income" ? "Walk-in customer" : "Supplier name"} className="focus-ring h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none placeholder:text-muted-foreground" /></label><label><span className="tiny-label mb-1.5 block">Category</span><select value={category} onChange={event => setCategory(event.target.value)} className="focus-ring h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none">{(kind === "income" ? ["Retail sales", "Wholesale", "Invoice payment", "Other income"] : categories.map(item => item.name)).map(item => <option key={item}>{item}</option>)}</select></label><label><span className="tiny-label mb-1.5 block">Account</span><select className="focus-ring h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none"><option>M-Pesa Till</option><option>NMB Business</option><option>Cash on hand</option></select></label></div><div className="mt-4 flex items-center justify-between rounded-xl border border-dashed border-border p-3"><div className="flex items-center gap-2 text-xs text-muted-foreground"><ScanLine size={15} className="text-[var(--gold)]" /> Scan a receipt to pre-fill</div><label className="cursor-pointer text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">{receiptName || "Upload"} <UploadCloud size={13} className="ml-1 inline" /><input type="file" accept="image/*,.pdf" className="hidden" onChange={event => { const file = event.target.files?.[0]; if (file) { setReceiptName(file.name); toast.success("Receipt attached", { description: "OCR review will suggest the amount, date and category." }); } }} /></label></div><div className="mt-6 flex justify-end gap-2"><button type="button" onClick={onClose} className="min-h-11 rounded-xl px-4 text-xs font-bold text-muted-foreground hover:bg-secondary">Cancel</button><button type="submit" className="min-h-11 rounded-xl bg-[var(--gold)] px-5 text-xs font-bold text-[#132b35]">Save {kind}</button></div></form></div>;
}

function MobileNav({ current, setPage }: { current: PageKey; setPage: (page: PageKey) => void }) {
  const items: NavItem[] = [{ label: "Dashboard", path: "dashboard", icon: LayoutDashboard }, { label: "Income", path: "income", icon: ArrowUpRight }, { label: "Expenses", path: "expenses", icon: ArrowDownRight }, { label: "Reports", path: "reports", icon: BarChart3 }, { label: "Settings", path: "settings", icon: Settings2 }];
  return <nav className="fixed inset-x-3 bottom-3 z-40 flex items-center justify-around rounded-2xl border border-border bg-card/95 p-2 shadow-xl backdrop-blur lg:hidden">{items.map(item => { const Icon = item.icon; const active = current === item.path; return <button key={item.path} onClick={() => setPage(item.path)} className={`focus-ring flex min-h-12 min-w-[52px] flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-semibold ${active ? "bg-[var(--navy)] text-white dark:bg-[var(--gold)] dark:text-[#132b35]" : "text-muted-foreground"}`}><Icon size={17} /><span className="mt-0.5 leading-none">{item.label}</span></button>; })}</nav>;
}

function Sidebar({ current, setPage, onQuickAdd, onOpenAssistant }: { current: PageKey; setPage: (page: PageKey) => void; onQuickAdd: () => void; onOpenAssistant: () => void }) {
  const group = (label: string, items: NavItem[]) => <div className="mb-6"><div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[.16em] text-white/35">{label}</div><div className="space-y-1">{items.map(item => { const Icon = item.icon; const active = current === item.path; return <button key={item.path} onClick={() => setPage(item.path)} className={`focus-ring flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-left text-sm transition ${active ? "bg-white/10 font-semibold text-white" : "text-white/60 hover:bg-white/5 hover:text-white"}`}><Icon size={17} strokeWidth={active ? 2.2 : 1.8} /><span className="flex-1">{item.label}</span>{item.path === "reports" && <span className="rounded-full bg-[#e8d7b6] px-1.5 py-0.5 text-[9px] font-bold text-[#132b35]">NEW</span>}</button>; })}</div></div>;
  return <aside className="sidebar-scroll fixed inset-y-0 left-0 z-30 hidden w-[260px] flex-col overflow-y-auto bg-[var(--sidebar)] px-4 py-6 text-[var(--sidebar-foreground)] lg:flex"><div className="flex items-center gap-3 px-2"><LogoMark light /><div><div className="serif text-lg font-semibold tracking-tight">LedgerLine</div><div className="text-[10px] uppercase tracking-[.17em] text-white/45">Business, made clear</div></div></div><div className="mt-8 rounded-2xl border border-white/10 bg-white/[.05] p-3"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#e8d7b6] text-xs font-bold text-[#132b35]">AG</div><div className="min-w-0"><div className="truncate text-xs font-semibold">Amina's General Store</div><div className="mt-0.5 flex items-center gap-1 text-[10px] text-white/45"><span className="h-1.5 w-1.5 rounded-full bg-[#7fc59c]" /> Dar es Salaam · TZS</div></div><ChevronDown size={14} className="ml-auto text-white/45" /></div></div><button onClick={onQuickAdd} className="mt-5 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[var(--gold)] text-xs font-bold text-[#132b35] transition hover:brightness-105"><Plus size={16} /> Quick add</button><nav className="mt-8 flex-1">{group("Workspace", primaryNav)}{group("Manage", workspaceNav)}{group("Tools", toolNav)}</nav><div className="mt-4 space-y-1 border-t border-white/10 pt-4"><button onClick={onOpenAssistant} className="flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-sm text-white/65 hover:bg-white/5 hover:text-white"><Sparkles size={17} className="text-[#e8d7b6]" /> Finance Guide <span className="ml-auto h-2 w-2 rounded-full bg-[#7fc59c]" /></button><button onClick={() => setPage("help")} className="flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-sm text-white/65 hover:bg-white/5 hover:text-white"><HelpCircle size={17} /> Help center</button><button onClick={() => setPage("settings")} className="flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-sm text-white/65 hover:bg-white/5 hover:text-white"><Settings2 size={17} /> Settings</button></div><div className="mt-4 flex items-center gap-2 px-3 text-[10px] text-white/35"><ShieldCheck size={13} /> Your data stays yours</div></aside>;
}

export function LandingPage() {
  const [, setLocation] = useLocation();
  const [mobileMenu, setMobileMenu] = useState(false);
  return <div className="min-h-screen bg-[var(--ivory)] text-[var(--charcoal)]"><header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8 lg:px-10"><div className="flex items-center gap-3"><LogoMark /><div><div className="serif text-lg font-semibold tracking-tight">LedgerLine</div><div className="hidden text-[10px] uppercase tracking-[.16em] text-muted-foreground sm:block">Business, made clear</div></div></div><nav className="hidden items-center gap-7 text-sm font-semibold text-muted-foreground md:flex"><a href="#why" className="hover:text-foreground">Why LedgerLine</a><a href="#features" className="hover:text-foreground">Features</a><a href="#pricing" className="hover:text-foreground">Pricing</a><a href="#faq" className="hover:text-foreground">FAQ</a></nav><div className="flex items-center gap-2"><button onClick={() => setLocation("/app")} className="hidden min-h-10 px-3 text-xs font-bold text-muted-foreground sm:block">Sign in</button><button onClick={() => setLocation("/app")} className="min-h-10 rounded-xl bg-[var(--navy)] px-4 text-xs font-bold text-white shadow-sm dark:bg-[var(--forest)]">Try LedgerLine <ArrowRight size={14} className="ml-1 inline" /></button><button onClick={() => setMobileMenu(!mobileMenu)} className="rounded-xl p-2 md:hidden"><Menu size={19} /></button></div></header>{mobileMenu && <div className="mx-5 rounded-xl border border-border bg-card p-3 shadow-lg md:hidden"><a href="#why" onClick={() => setMobileMenu(false)} className="block rounded-lg p-3 text-sm font-semibold">Why LedgerLine</a><a href="#features" onClick={() => setMobileMenu(false)} className="block rounded-lg p-3 text-sm font-semibold">Features</a><a href="#pricing" onClick={() => setMobileMenu(false)} className="block rounded-lg p-3 text-sm font-semibold">Pricing</a></div>}<main><section className="hero-glow landing-grid relative overflow-hidden border-y border-[#d8cdbb] px-5 py-16 sm:px-8 sm:py-24 lg:px-10 lg:py-28"><div className="relative mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[.9fr_1.1fr]"><div className="max-w-2xl"><Pill tone="gold"><span className="h-1.5 w-1.5 rounded-full bg-[var(--gold)]" /> Built for the work behind the business</Pill><h1 className="serif mt-6 max-w-2xl text-[48px] font-semibold leading-[1.03] tracking-[-0.055em] text-[var(--navy)] sm:text-[68px]">Know what the month is <span className="text-[var(--gold)]">really</span> keeping.</h1><p className="mt-6 max-w-xl text-base leading-7 text-[#5d6863] sm:text-lg">LedgerLine gives small business owners a calm, clear view of income, expenses, profit and the next decision — without turning your day into a spreadsheet.</p><div className="mt-8 flex flex-wrap items-center gap-3"><button onClick={() => setLocation("/app")} className="flex min-h-12 items-center gap-2 rounded-xl bg-[var(--navy)] px-5 text-sm font-bold text-white shadow-lg shadow-[#132b35]/15">Start with your numbers <ArrowRight size={16} /></button><a href="#why" className="flex min-h-12 items-center gap-2 rounded-xl border border-[#cdbfa8] px-5 text-sm font-bold text-[var(--navy)]">See how it works <ChevronRight size={16} /></a></div><div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-[#68736f]"><span className="flex items-center gap-2"><ShieldCheck size={15} className="text-[var(--forest)]" /> Private by design</span><span className="flex items-center gap-2"><CircleCheck size={15} className="text-[var(--forest)]" /> TZS-ready</span><span className="flex items-center gap-2"><Zap size={15} className="text-[var(--gold)]" /> Start in minutes</span></div></div><div className="relative"><div className="absolute -inset-6 rounded-[2rem] bg-[#b68b45]/10 blur-2xl" /><div className="relative rounded-[1.5rem] border border-[#d4c5ad] bg-[#fffdf9]/90 p-3 shadow-2xl shadow-[#132b35]/10 backdrop-blur sm:p-4"><div className="flex items-center justify-between border-b border-[#ded2be] px-2 pb-3"><div className="flex items-center gap-2"><LogoMark /><div><div className="serif text-sm font-semibold">LedgerLine</div><div className="text-[9px] uppercase tracking-[.13em] text-[#8d938b]">Overview</div></div></div><div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#7eb78e]" /><span className="text-[10px] font-semibold text-[#68736f]">Synced just now</span></div></div><div className="grid gap-3 p-2 pt-4 sm:grid-cols-3"><div className="rounded-xl bg-[#f5f0e7] p-3"><div className="text-[9px] font-bold uppercase tracking-[.15em] text-[#8d938b]">Net profit</div><div className="serif mt-2 text-2xl font-semibold text-[#17211f]">TZS 4.2m</div><div className="mt-1 text-[10px] font-bold text-[#2e7755]">↗ 18.5%</div></div><div className="rounded-xl bg-[#f5f0e7] p-3"><div className="text-[9px] font-bold uppercase tracking-[.15em] text-[#8d938b]">Cash balance</div><div className="serif mt-2 text-2xl font-semibold text-[#17211f]">TZS 4.86m</div><div className="mt-1 text-[10px] font-bold text-[#2e7755]">↗ 9.4%</div></div><div className="rounded-xl bg-[#132b35] p-3 text-white"><div className="text-[9px] font-bold uppercase tracking-[.15em] text-[#d6c49e]">Health score</div><div className="serif mt-2 text-2xl font-semibold">90<span className="text-sm text-[#d6c49e]">/100</span></div><div className="mt-1 text-[10px] font-bold text-[#a8d0b0]">Healthy month</div></div></div><div className="grid gap-3 p-2 sm:grid-cols-[1.3fr_.7fr]"><div className="rounded-xl border border-[#e1dacf] p-3"><div className="flex items-center justify-between"><div className="text-[10px] font-bold uppercase tracking-[.12em] text-[#8d938b]">Cash movement</div><div className="text-[9px] text-[#8d938b]">Oct 2026</div></div><div className="mt-3 flex h-28 items-end gap-2">{[42,58,49,74,68,88,78,94,80,100,93,108].map((height, i) => <div key={i} className="flex-1 rounded-t bg-[#285347]" style={{ height: `${height}%`, opacity: i > 8 ? 1 : .7 }} />)}</div><div className="mt-3 flex justify-between text-[9px] text-[#8d938b]"><span>Apr</span><span>May</span><span>Jun</span><span>Jul</span><span>Aug</span><span>Sep</span></div></div><div className="rounded-xl bg-[#f5f0e7] p-3"><div className="text-[10px] font-bold uppercase tracking-[.12em] text-[#8d938b]">Smart insight</div><div className="mt-4 flex h-8 w-8 items-center justify-center rounded-lg bg-[#e8d7b6] text-[#7c5b2f]"><Sparkles size={14} /></div><p className="mt-3 text-xs leading-5 text-[#33423d]">Transport is TZS 728k, 14% of expenses. Saturday is your best sales day.</p></div></div></div><div className="absolute -bottom-5 -left-8 hidden w-52 rounded-xl border border-[#d4c5ad] bg-[#fffdf9] p-3 shadow-xl sm:block"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#e4f0e8] text-[#2e7755]"><ArrowUpRight size={15} /></div><div><div className="text-[10px] font-bold text-[#68736f]">Income today</div><div className="money text-sm font-bold">TZS 1,380,000</div></div></div></div></div></div></section><section id="why" className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:px-10 lg:py-28"><div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr]"><div><div className="tiny-label">One clear place to begin</div><h2 className="serif mt-3 max-w-md text-[35px] font-semibold leading-tight tracking-[-.04em]">The right numbers should feel like a relief.</h2><p className="mt-5 max-w-md text-sm leading-7 text-muted-foreground">Most small-business tools make you work for the answer. LedgerLine puts your best next decision closer to the surface.</p></div><div className="grid gap-5 sm:grid-cols-3"><div className="app-card p-5"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e4ebed] text-[#23424c]"><BarChart3 size={18} /></div><h3 className="serif mt-5 text-lg font-semibold">See the truth</h3><p className="mt-2 text-xs leading-5 text-muted-foreground">Profit, cash and the cost of getting there — together.</p></div><div className="app-card p-5"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f2e8d4] text-[#8a6735]"><Sparkles size={18} /></div><h3 className="serif mt-5 text-lg font-semibold">Ask naturally</h3><p className="mt-2 text-xs leading-5 text-muted-foreground">Ask “what changed?” and get a useful answer in plain language.</p></div><div className="app-card p-5"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e4f0e8] text-[#2e7755]"><UploadCloud size={18} /></div><h3 className="serif mt-5 text-lg font-semibold">Save the time</h3><p className="mt-2 text-xs leading-5 text-muted-foreground">Bring in mobile money and bank statements instead of typing twice.</p></div></div></div></section><section id="features" className="bg-[var(--navy)] px-5 py-20 text-white sm:px-8 lg:px-10 lg:py-28"><div className="mx-auto max-w-7xl"><div className="max-w-2xl"><div className="tiny-label text-[#d6c49e]">One workspace, many small wins</div><h2 className="serif mt-3 text-[38px] font-semibold leading-tight tracking-[-.04em]">Everything that keeps the business moving.</h2></div><div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-4">{[{ icon: Sparkles, title: "Finance Guide", text: "Ask questions. Get the chart, not the jargon." }, { icon: UploadCloud, title: "Statement import", text: "M-Pesa, Tigo Pesa, Airtel Money and bank-ready." }, { icon: UsersRound, title: "People directory", text: "Know who owes what, with a tap to call or WhatsApp." }, { icon: ShoppingBag, title: "Fast POS", text: "Sell, share the receipt and keep the ledger moving." }, { icon: Activity, title: "Health score", text: "A 0–100 read on margin, runway, debt and growth." }, { icon: SlidersHorizontal, title: "Your dashboard", text: "Pin the reports that matter. Hide what does not." }, { icon: Globe2, title: "Branches", text: "View one shop or the business together." }, { icon: LockKeyhole, title: "Close the month", text: "Lock finished numbers and move forward with confidence." }].map(item => <div key={item.title} className="bg-[var(--navy)] p-6 transition hover:bg-white/[.06]"><item.icon size={21} className="text-[#e8d7b6]" /><h3 className="serif mt-6 text-xl font-semibold">{item.title}</h3><p className="mt-2 text-sm leading-6 text-white/55">{item.text}</p></div>)}</div></div></section><section id="pricing" className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:px-10 lg:py-28"><div className="text-center"><div className="tiny-label">A plan for where you are</div><h2 className="serif mt-3 text-[38px] font-semibold tracking-[-.04em]">Start simply. Grow into clarity.</h2><p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-muted-foreground">Your first month should feel lighter, not like another commitment to manage.</p></div><div className="mx-auto mt-12 grid max-w-5xl gap-4 lg:grid-cols-3">{[{ name: "Free", price: "TZS 0", note: "For getting started", features: ["Income & expense tracking", "Monthly dashboard", "Basic reports", "One business"] }, { name: "Pro", price: "TZS 18,000", note: "For a business in motion", features: ["Everything in Free", "AI Finance Guide", "Statement imports", "VAT & tax mode", "Budgets, goals and alerts"], featured: true }, { name: "Business", price: "TZS 48,000", note: "For teams and branches", features: ["Everything in Pro", "Multiple businesses", "Roles and permissions", "Advanced exports", "Priority support"] }].map(plan => <div key={plan.name} className={`relative rounded-2xl border p-6 ${plan.featured ? "border-[var(--gold)] bg-[var(--navy)] text-white shadow-2xl lg:-translate-y-3" : "border-border bg-card"}`}><div className="flex items-center justify-between"><h3 className="serif text-2xl font-semibold">{plan.name}</h3>{plan.featured && <Pill tone="gold">Most loved</Pill>}</div><p className={`mt-2 text-xs ${plan.featured ? "text-white/55" : "text-muted-foreground"}`}>{plan.note}</p><div className="serif mt-7 text-3xl font-semibold">{plan.price}<span className={`font-sans text-xs font-normal ${plan.featured ? "text-white/55" : "text-muted-foreground"}`}>{plan.name !== "Free" && " / month"}</span></div><button onClick={() => setLocation("/app")} className={`mt-7 flex min-h-11 w-full items-center justify-center rounded-xl text-xs font-bold ${plan.featured ? "bg-[var(--gold)] text-[#132b35]" : "bg-secondary text-foreground"}`}>{plan.name === "Free" ? "Start free" : "Choose plan"}</button><div className={`ledger-rule mt-7 pt-5 ${plan.featured ? "border-[#e8d7b6]" : ""}`}><div className="space-y-3">{plan.features.map(feature => <div key={feature} className="flex items-center gap-2 text-xs"><Check size={14} className={plan.featured ? "text-[#e8d7b6]" : "text-[var(--forest)]"} />{feature}</div>)}</div></div></div>)}</div></section><section id="faq" className="border-t border-border bg-[#f0ece4] px-5 py-20 sm:px-8 lg:px-10 lg:py-24"><div className="mx-auto grid max-w-5xl gap-10 lg:grid-cols-[.65fr_1.35fr]"><div><div className="tiny-label">Frequently asked</div><h2 className="serif mt-3 text-[34px] font-semibold tracking-[-.04em]">Good questions deserve clear answers.</h2></div><div className="space-y-3">{[{ q: "Can I use LedgerLine for M-Pesa and cash?", a: "Yes. LedgerLine is designed around the accounts small businesses actually use — cash, bank, mobile money and card wallets." }, { q: "Does it work in Swahili?", a: "English and Swahili are switchable from settings, so your team can use the language that feels most natural." }, { q: "Can I lock a month after closing?", a: "Yes. Month-end close creates a visible lock so finished numbers cannot be edited by accident." }, { q: "What happens to my data?", a: "Your financial pages are treated as private, with no sensitive data in URLs and no client-side caching of finance records." }].map(item => <details key={item.q} className="group rounded-xl border border-border bg-card p-4"><summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-semibold">{item.q}<ChevronDown size={16} className="shrink-0 transition group-open:rotate-180" /></summary><p className="mt-3 max-w-2xl text-xs leading-6 text-muted-foreground">{item.a}</p></details>)}</div></div></section></main><footer className="bg-[var(--navy)] px-5 py-8 text-white sm:px-8 lg:px-10"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-5 sm:flex-row sm:items-center"><div className="flex items-center gap-3"><LogoMark light /><div><div className="serif text-lg font-semibold">LedgerLine</div><div className="text-[10px] uppercase tracking-[.15em] text-white/45">A clearer ledger</div></div></div><div className="flex flex-wrap items-center gap-4 text-xs text-white/45"><span>Built for small business</span><span>·</span><span>TZS-ready</span><span>·</span><button onClick={() => setLocation("/app")} className="font-bold text-[#e8d7b6]">Open demo <ArrowRight size={13} className="ml-1 inline" /></button></div></div></footer></div>;
}

export function Workspace() {
  const [location, setLocation] = useLocation();
  const [transactions, setTransactions] = useState<Transaction[]>(demoTransactions);
  const [period, setPeriod] = useState("This month");
  const [comparison, setComparison] = useState("Last month");
  const [quickAddKind, setQuickAddKind] = useState<"income" | "expense">("income");
  const [search, setSearch] = useState("");
  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [tourOpen, setTourOpen] = useState(true);
  const [language, setLanguage] = useState<"en" | "sw">("en");
  const [online, setOnline] = useState(true);
  const [auditLog, setAuditLog] = useState<string[]>([]);
  const ledgerQuery = trpc.ledger.list.useQuery(undefined, { retry: false, enabled: online });
  const createLedger = trpc.ledger.create.useMutation();
  const { theme, toggleTheme } = useTheme();
  useEffect(() => {
    setOnline(navigator.onLine);
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    const saved = localStorage.getItem("ledgerline-transactions");
    if (saved) { try { setTransactions(JSON.parse(saved) as Transaction[]); } catch { localStorage.removeItem("ledgerline-transactions"); } }
    return () => { window.removeEventListener("online", onOnline); window.removeEventListener("offline", onOffline); };
  }, []);
  useEffect(() => { localStorage.setItem("ledgerline-transactions", JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { if (ledgerQuery.data?.length) { const rows = ledgerQuery.data.map(row => ({ id: `DB-${row.id}`, kind: row.kind, date: new Date(row.occurredAt).toLocaleDateString("en-TZ", { day: "2-digit", month: "short" }), description: row.description, category: row.category, counterparty: "Ledger account", amount: row.amount, account: "Connected account", initials: "DB", color: row.kind === "income" ? "#2E7755" : "#A55E5A", status: (row.status === "pending" ? "Pending" : "Cleared") as "Pending" | "Cleared" })); setTransactions(rows); appendAudit(`${rows.length} transactions synced from the database`); } }, [ledgerQuery.data]);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); setCommandOpen(true); } };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);
  const rawPage = location.replace(/^\/app\/?/, "").split("/")[0] || "dashboard";
  const knownPages: PageKey[] = ["dashboard", "income", "expenses", "reports", "budgets", "debts", "inventory", "invoices", "accounts", "calendar", "contacts", "pos", "notifications", "settings", "help", "recurring", "tools"];
  const current = (knownPages.includes(rawPage as PageKey) ? rawPage : "dashboard") as PageKey;
  const setPage = (page: PageKey) => setLocation(page === "dashboard" ? "/app" : `/app/${page}`);
  const openQuickAdd = (kind: "income" | "expense" = "income") => { setQuickAddKind(kind); setQuickAddOpen(true); };
  const appendAudit = (message: string) => setAuditLog(currentLog => [`${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · ${message}`, ...currentLog]);
  const addTransaction = (draft: { kind: "income" | "expense"; amount: number; description: string; category: string; counterparty: string; account: string }) => { const initials = draft.counterparty.split(" ").map(word => word[0]).join("").slice(0, 2).toUpperCase(); const localRow = { id: `TX-${1049 + transactions.length}`, kind: draft.kind, date: "08 Oct, 2026", description: draft.description, category: draft.category, counterparty: draft.counterparty, amount: draft.amount, account: draft.account, initials: initials || "LL", color: draft.kind === "income" ? "#2E7755" : "#A55E5A", status: "Cleared" as const }; setTransactions(currentTransactions => [localRow, ...currentTransactions]); createLedger.mutate({ kind: draft.kind, amount: Math.round(draft.amount), description: draft.description, category: draft.category, note: draft.counterparty, occurredAt: new Date() }, { onError: () => appendAudit("Saved offline; waiting for database sync") }); setQuickAddOpen(false); appendAudit(`${draft.kind === "income" ? "Income" : "Expense"} saved: ${draft.description}`); toast.success(`${draft.kind === "income" ? "Income" : "Expense"} saved`, { description: `${formatTZS(draft.amount)} added to your ledger.` }); };
  const importTransactions = (items: Transaction[], source: string) => { setTransactions(current => [...items, ...current]); appendAudit(`${items.length} rows imported from ${source}`); };
  const backup = () => { const blob = new Blob([JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), transactions }, null, 2)], { type: "application/json" }); const url = URL.createObjectURL(blob); const anchor = document.createElement("a"); anchor.href = url; anchor.download = "ledgerline-backup.json"; anchor.click(); URL.revokeObjectURL(url); appendAudit("Workspace backup downloaded"); toast.success("Backup downloaded"); };
  const restore = async (file: File) => { try { const data = JSON.parse(await file.text()) as { transactions?: Transaction[] }; if (!Array.isArray(data.transactions)) throw new Error("Invalid backup"); setTransactions(data.transactions); appendAudit(`Workspace restored from ${file.name}`); toast.success("Backup restored", { description: `${data.transactions.length} transactions are back in the ledger.` }); } catch { toast.error("Could not restore backup", { description: "Choose a LedgerLine JSON backup file." }); } };
  const renderPage = () => { if (current === "dashboard") return <Dashboard transactions={transactions} setPage={setPage} period={period} setPeriod={setPeriod} comparison={comparison} setComparison={setComparison} onQuickAdd={openQuickAdd} onOpenAssistant={() => setAssistantOpen(true)} online={online} />; if (current === "income") return <LedgerPage kind="income" transactions={transactions} onQuickAdd={() => setQuickAddOpen(true)} search={search} setSearch={setSearch} />; if (current === "expenses") return <LedgerPage kind="expense" transactions={transactions} onQuickAdd={() => setQuickAddOpen(true)} search={search} setSearch={setSearch} />; if (current === "reports") return <ReportsPage period={period} setPeriod={setPeriod} comparison={comparison} setComparison={setComparison} transactions={transactions} />; if (current === "budgets") return <AdvancedBudgetsPage />; if (current === "debts") return <AdvancedDebtsPage />; if (current === "inventory") return <AdvancedInventoryPage />; if (current === "invoices") return <AdvancedInvoicesPage />; if (current === "accounts") return <AdvancedAccountsPage />; if (current === "calendar") return <AdvancedCalendarPage />; if (current === "contacts") return <AdvancedContactsPage />; if (current === "recurring") return <AdvancedRecurringPage />; if (current === "tools") return <AdvancedToolsPage transactions={transactions} onImport={importTransactions} onBackup={backup} onRestore={restore} auditLog={auditLog} online={online} language={language} setLanguage={setLanguage} />; if (current === "pos") return <PosPage onAdd={(amount, description) => addTransaction({ kind: "income", amount, description, category: "Retail sales", counterparty: "Walk-in customer", account: "M-Pesa Till" })} />; return <UtilityPage page={current} />; };
  return <div className="min-h-screen bg-background text-foreground"><Sidebar current={current} setPage={setPage} onQuickAdd={() => setQuickAddOpen(true)} onOpenAssistant={() => setAssistantOpen(true)} /><div className="min-h-screen lg:pl-[260px]"><header className="sticky top-0 z-20 flex h-[74px] items-center justify-between border-b border-border/80 bg-background/90 px-4 backdrop-blur sm:px-6 lg:px-9"><div className="flex items-center gap-3 lg:hidden"><LogoMark /><div className="serif text-lg font-semibold">LedgerLine</div></div><div className="hidden items-center gap-2 text-xs text-muted-foreground lg:flex"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary"><Command size={14} /></span><span>Press <kbd className="mx-1 rounded border border-border px-1.5 py-0.5 text-[10px]">⌘ K</kbd> to search anything</span></div><div className="ml-auto flex items-center gap-2"><button className="focus-ring flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground hover:bg-secondary lg:hidden"><Search size={17} /></button><button onClick={() => setAssistantOpen(true)} className="focus-ring hidden h-10 items-center gap-2 rounded-xl border border-border bg-card px-3 text-xs font-semibold text-muted-foreground hover:bg-secondary sm:flex"><Sparkles size={15} className="text-[var(--gold)]" /> Ask Finance Guide</button><button onClick={() => toast.info("Notifications", { description: "You have one budget alert and one bill due in 12 days." })} className="focus-ring relative flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground hover:bg-secondary"><Bell size={17} /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[var(--gold)]" /></button><button onClick={toggleTheme} className="focus-ring flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground hover:bg-secondary" aria-label="Toggle theme">{theme === "light" ? <Moon size={17} /> : <Sun size={17} />}</button><div className="hidden h-10 w-px bg-border sm:block" /><button onClick={() => setPage("settings")} className="hidden items-center gap-2 rounded-xl px-1 text-left sm:flex"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--navy)] text-[11px] font-bold text-[#e8d7b6] dark:bg-[var(--gold)] dark:text-[#132b35]">AG</div><div className="hidden xl:block"><div className="text-xs font-bold">Amina G.</div><div className="text-[10px] text-muted-foreground">Owner</div></div><ChevronDown size={14} className="text-muted-foreground" /></button></div></header><main className="mobile-safe-bottom app-scroll min-h-[calc(100vh-74px)] overflow-x-hidden px-4 py-7 sm:px-6 lg:px-9 lg:py-9">{renderPage()}</main></div><MobileNav current={current} setPage={setPage} />{tourOpen && current === "dashboard" && <div className="fixed bottom-24 left-4 z-30 max-w-[285px] rounded-2xl border border-[var(--gold)]/35 bg-card p-4 shadow-xl lg:bottom-6 lg:left-[285px]"><button onClick={() => setTourOpen(false)} className="absolute right-2 top-2 p-1 text-muted-foreground"><X size={14} /></button><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#f2e8d4] text-[#8a6735]"><Sparkles size={15} /></div><div className="text-xs font-bold">A calmer way to begin</div></div><p className="mt-3 pr-2 text-xs leading-5 text-muted-foreground">Start with the six figures above. When a number moves, Finance Guide can help explain why.</p><button onClick={() => { setTourOpen(false); setAssistantOpen(true); }} className="mt-3 text-xs font-bold text-[var(--forest)] dark:text-[var(--gold)]">Take the two-minute tour <ArrowRight size={13} className="ml-1 inline" /></button></div>}{quickAddOpen && <QuickAddModal initialKind={quickAddKind} onClose={() => setQuickAddOpen(false)} onSave={addTransaction} />}{assistantOpen && <AssistantPanel transactions={transactions} onClose={() => setAssistantOpen(false)} />}{commandOpen && <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} onNavigate={page => { setPage(page); setCommandOpen(false); }} onAssistant={() => setAssistantOpen(true)} />}</div>;
}
