import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InsertTransaction, businesses, transactions, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOwnedBusiness(userId: number, businessId?: number) {
  const db = await getDb();
  if (!db) return undefined;
  const where = businessId ? and(eq(businesses.ownerId, userId), eq(businesses.id, businessId)) : eq(businesses.ownerId, userId);
  const result = await db.select().from(businesses).where(where).limit(1);
  return result[0];
}
export async function getOrCreateOwnedBusiness(userId: number, businessId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getOwnedBusiness(userId, businessId);
  if (existing) return existing;
  await db.insert(businesses).values({ ownerId: userId, name: "Amina's General Store", currency: "TZS", taxRate: 18 });
  const created = await getOwnedBusiness(userId);
  if (!created) throw new Error("Business could not be created");
  return created;
}

export async function listOwnedTransactions(userId: number, businessId?: number, limit = 100) {
  const db = await getDb();
  if (!db) return [];
  const business = await getOwnedBusiness(userId, businessId);
  if (!business) return [];
  return db.select().from(transactions).where(eq(transactions.businessId, business.id)).orderBy(desc(transactions.occurredAt)).limit(Math.min(limit, 250));
}

export async function summarizeOwnedTransactions(userId: number, businessId?: number) {
  const db = await getDb();
  if (!db) return { income: 0, expenses: 0, profit: 0, margin: 0 };
  const business = await getOwnedBusiness(userId, businessId);
  if (!business) return { income: 0, expenses: 0, profit: 0, margin: 0 };
  const rows = await db.select({ kind: transactions.kind, total: sql<number>`coalesce(sum(${transactions.amount}), 0)` }).from(transactions).where(eq(transactions.businessId, business.id)).groupBy(transactions.kind);
  const income = Number(rows.find(row => row.kind === "income")?.total ?? 0);
  const expenses = Number(rows.find(row => row.kind === "expense")?.total ?? 0);
  const profit = income - expenses;
  return { income, expenses, profit, margin: income ? (profit / income) * 100 : 0 };
}

export async function createOwnedTransaction(userId: number, input: Omit<InsertTransaction, "businessId" | "createdBy"> & { businessId?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const business = await getOrCreateOwnedBusiness(userId, input.businessId);
  const values: InsertTransaction = { ...input, businessId: business.id, createdBy: userId };
  await db.insert(transactions).values(values);
  return values;
}
